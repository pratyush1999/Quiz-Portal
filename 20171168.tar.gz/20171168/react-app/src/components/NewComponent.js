import React, { Component } from 'react';
// import './App.css';

class NewComponent extends Component {
  render() {
    return (
        <h2> {this.props.text} </h2>
    );
  }
}

export default NewComponent;
